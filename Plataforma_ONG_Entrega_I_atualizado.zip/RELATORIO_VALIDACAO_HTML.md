
# Relatório de Validação HTML (Modelo)

Use o W3C Markup Validation (https://validator.w3.org/). Preencha:

## index.html
Data: ____/____/____ — Resultado: [ ] OK [ ] Avisos [ ] Erros — Observações: ______

## sobre.html
[...] (repita para todas)
