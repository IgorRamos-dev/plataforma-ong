
# Documentação dos Gráficos (Canvas)

Arquivo: `js/charts.js` (Canvas 2D puro).
- Pizza: distribuição de recursos por projeto.
- Linha: evolução mensal de voluntários.
- Barras: impacto por região.

Acessibilidade: cada `<canvas>` tem `aria-label` e `role="img"`.
